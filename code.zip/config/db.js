const mongooseConfig = { 
    useNewUrlParser: true,
    useUnifiedTopology: true
};

exports.mongooseConfig = mongooseConfig;
