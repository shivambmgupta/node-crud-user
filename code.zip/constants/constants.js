const APP_CONSTANTS = {
    WELCOME: 'Welcome!',
    SERVER_UP: 'Server is up and running',
    DB_CONNECTED: 'Connected with the database',
    DB_ERROR: 'Database connection failure',
    DEFAULT_SOURCE: 'Signzy',
    WHO_AM_I: 'whoAmICookie'
};

exports.APP_CONSTANTS = APP_CONSTANTS;
